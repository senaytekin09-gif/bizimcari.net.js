/* bizimcari.net — sunucu bağlayıcısı: sayfanın kullandığı db / user / downloads arayüzünü kendi sunucunuza bağlar. */
(function () {
  'use strict';
  var YOKLA = 4000;
  function hata(kod, msg) { var e = new Error(msg || kod); e.code = kod; return e; }
  async function istek(yol, init) {
    var r;
    try { r = await fetch(yol, Object.assign({ credentials: 'same-origin', headers: { 'Content-Type': 'application/json' } }, init)); }
    catch (e) { throw hata('unavailable', 'Sunucuya ulaşılamadı'); }
    var j = null; try { j = await r.json(); } catch (e) {}
    if (!r.ok) throw hata(r.status === 401 ? 'unauthenticated' : r.status === 403 ? 'permission_denied' : r.status === 413 ? 'quota_exceeded' : r.status >= 500 ? 'unavailable' : 'invalid_argument', (j && j.hata) || ('HTTP ' + r.status));
    return j;
  }
  var benP = null;
  function ben() { return benP || (benP = fetch('/api/me', { credentials: 'same-origin' }).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; })); }

  function belge(p) {
    return {
      id: p.split('/').pop(),
      get: async function () { var j = await istek('/api/doc?path=' + encodeURIComponent(p)); return { exists: !!j.exists, data: function () { return j.data; } }; },
      set: async function (v) { await istek('/api/doc?path=' + encodeURIComponent(p), { method: 'PUT', body: JSON.stringify(v) }); }
    };
  }
  function koleksiyon(c) {
    async function oku() { return (await istek('/api/col?path=' + encodeURIComponent(c))).docs; }
    return {
      get: async function () { var d = await oku(); return { docs: d.map(function (x) { return { id: x.id, data: function () { return x.data; } }; }) }; },
      onSnapshot: function (ok, err) {
        var son = {}, ilk = true, dur = false, zm = null;
        async function tur() {
          if (dur) return;
          try {
            var d = await oku(), ch = [];
            d.forEach(function (x) { if (son[x.id] !== x.t) { son[x.id] = x.t; ch.push({ type: 'added', doc: { id: x.id, data: function () { return x.data; }, metadata: {} } }); } });
            if (ilk || ch.length) { ilk = false; ok({ docChanges: function () { return ch; } }); }
          } catch (e) { if (ilk) { ilk = false; if (err) err(e); } }
          if (!dur) zm = setTimeout(tur, YOKLA);
        }
        tur();
        return function () { dur = true; clearTimeout(zm); };
      }
    };
  }
  var dbN = { doc: belge, collection: koleksiyon };

  async function indir(o) {
    var blob = o.data instanceof Blob ? o.data : new Blob([o.data]);
    var u = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = u; a.download = o.filename || 'dosya'; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(u); }, 4000);
  }

  window.claude = {
    use: async function (ad) {
      if (ad === 'downloads') return { save: indir };
      var m = await ben(); if (!m) return null;
      if (ad === 'db') return dbN;
      if (ad === 'user') return {
        id: async function () { return m.id; },
        me: async function () { return { id: m.id }; },
        canEdit: function () { return !!m.admin; },
        isOwner: function () { return !!m.admin; },
        can: function () { return true; }
      };
      return null;
    },
    __sifirla: function () { benP = null; }
  };
})();
