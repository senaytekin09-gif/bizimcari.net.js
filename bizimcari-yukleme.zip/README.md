# bizimcari.net — Kendi Sunucunuzda Kurulum

Bu klasör, bizimcari.net satış sürümünün kendi sunucunuzda çalışan halidir.
Gerçek bir sunucu ve veritabanı içerir: hesap (e-posta + şifre), oturum, her müşteriye özel veri, plan satın alma talepleri ve yönetici onayı.

- **Gereksinim:** Node.js 22.5 veya üstü. Dış paket (npm install) gerekmez.
- **Veritabanı:** SQLite, tek dosya (`data/bizimcari.db`). Yedek almak için bu dosyayı kopyalamanız yeterlidir.
- **PDF / Excel:** Kütüphaneler `public/vendor` içinde, internetten indirilmez. (Yalnızca fotoğraftan metin okuma özelliği harici bir kaynaktan yüklenir.)

## 1. Hızlı başlangıç

```bash
cd bizimcari-host
ADMIN_EMAIL=siz@alanadiniz.com npm start
# http://127.0.0.1:3000
```

**Önemli:** İlk olarak `ADMIN_EMAIL` ile verdiğiniz adresle kayıt olun. Yönetici (Satış Yönetimi: talepleri onaylama, IBAN girme) yalnızca o hesaptır.
`ADMIN_EMAIL` verilmezse, ilk kayıt olan hesap yönetici olur.

## 2. Ortam değişkenleri

| Değişken | Varsayılan | Anlamı |
|---|---|---|
| `PORT` | 3000 | Dinlenen port |
| `HOST` | 127.0.0.1 | Dış erişim için `0.0.0.0` (genelde ters vekil arkasında 127.0.0.1 bırakın) |
| `DATA_DIR` | ./data | Veritabanı klasörü |
| `ADMIN_EMAIL` | (boş) | Yönetici hesabın e-postası |
| `COOKIE_SECURE` | 0 | HTTPS arkasında **1** yapın |
| `TRUST_PROXY` | 0 | Nginx/Caddy arkasında **1** yapın (istemci IP'si için) |

## 3. Alan adı ve HTTPS (bizimcari.net)

1. Alan adınızın DNS **A kaydını** sunucunuzun IP adresine yönlendirin (`bizimcari.net` ve `www`).
2. Sunucuya Caddy kurun (otomatik ücretsiz HTTPS sertifikası alır). `/etc/caddy/Caddyfile`:

```
bizimcari.net, www.bizimcari.net {
    reverse_proxy 127.0.0.1:3000
}
```

3. Uygulamayı şu değişkenlerle çalıştırın: `COOKIE_SECURE=1 TRUST_PROXY=1 ADMIN_EMAIL=siz@bizimcari.net`.

### Sürekli çalışması için (systemd)

`/etc/systemd/system/bizimcari.service`:

```
[Unit]
Description=bizimcari.net
After=network.target

[Service]
WorkingDirectory=/opt/bizimcari-host
Environment=ADMIN_EMAIL=siz@bizimcari.net COOKIE_SECURE=1 TRUST_PROXY=1 DATA_DIR=/var/lib/bizimcari
ExecStart=/usr/bin/node --disable-warning=ExperimentalWarning server.js
Restart=always
User=bizimcari

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now bizimcari
```

### Docker ile

```bash
docker build -t bizimcari .
docker run -d --name bizimcari -p 127.0.0.1:3000:3000 -v bizimcari-data:/data \
  -e ADMIN_EMAIL=siz@bizimcari.net --restart always bizimcari
```

## 4. İşletme

- **Plan satışı:** Müşteri "Planlar" sayfasından talep gönderir (havale/EFT). Siz "Satış Yönetimi" sayfasında ödemeyi görüp onaylarsınız; plan 30 gün açılır. IBAN bilginizi aynı sayfadan girin.
- **Şifre sıfırlama:** `node server.js --sifre musteri@ornek.com yeniSifre123` (açık oturumlar kapatılır). E-postayla otomatik sıfırlama yoktur.
- **Yedek:** `data/` klasörünü düzenli kopyalayın (ör. gece `sqlite3 data/bizimcari.db ".backup yedek.db"`).
- **Güncelleme:** `public/index.html` dosyasını değiştirip sayfayı yenilemek yeterlidir; sunucuyu yeniden başlatmanız gerekmez.

## 5. Bilmeniz gerekenler (dürüst sınırlar)

- **Kartla ödeme yoktur.** Gerçek kart tahsilatı için iyzico / PayTR gibi bir ödeme sağlayıcısının entegrasyonu gerekir; bu pakette yok.
- **Lisans denetimi istemcidedir.** Plan süresi ve kilit mantığı sayfada çalışır; teknik bilgisi olan bir müşteri kendi tarayıcısında bunu aşabilir. Plan onayı (`onay`) sunucuda yalnızca yönetici tarafından yazılabilir, ancak kilidi uygulayan kod tarayıcıdadır. Ticari kullanımda lisans kontrolünün sunucuya taşınması önerilir.
- **Veri gizliliği:** Her müşterinin verisi yalnızca kendi hesabıyla okunur/yazılır (sunucuda zorlanır). Yönetici bile müşteri verisini API ile okuyamaz; ancak sunucuya ve veritabanı dosyasına erişen kişi okuyabilir. KVKK kapsamında veri sorumlusu sizsiniz: aydınlatma metni, saklama süresi ve yedek şifreleme sizin sorumluluğunuzdadır.
- **E-posta gönderimi yoktur** (doğrulama, şifre sıfırlama, bildirim). İletişim adresi `destek@bizimcari.net` ve Referanslar metni örnektir; `public/index.html` içinde kendi bilgilerinizle değiştirin.
- **Gizli benzetim modülleri:** B2B, e-Belge, e-Ticaret, Döviz, Banka entegrasyonu ve Mali müşavir gerçek bağlantı içermediği için kapalıdır.
- **Giriş denemesi sınırı:** IP başına dakikada 10 deneme. Bellekte tutulur, yeniden başlatmada sıfırlanır.
