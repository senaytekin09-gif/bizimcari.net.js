// bizimcari.net — kendi sunucunuzda çalışan bulut ön muhasebe sunucusu
// Gereksinim: Node.js 22.5 veya üstü. Dış paket gerekmez (node:sqlite kullanır).
'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = +process.env.PORT || 3000;
const HOST = process.env.HOST || '127.0.0.1';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const COOKIE_SECURE = process.env.COOKIE_SECURE === '1';
const OTURUM_GUN = 30;
const MAX_GOVDE = 5 * 1024 * 1024;
const PUBLIC = path.join(__dirname, 'public');

fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DATA_DIR, 'bizimcari.db'));
db.exec(`
PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, hash TEXT NOT NULL, salt TEXT NOT NULL, admin INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id TEXT NOT NULL, exp INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS kv(path TEXT PRIMARY KEY, val TEXT NOT NULL, t INTEGER NOT NULL);
`);
const q = {
  userByEmail: db.prepare('SELECT * FROM users WHERE email=?'),
  userById: db.prepare('SELECT * FROM users WHERE id=?'),
  userCount: db.prepare('SELECT COUNT(*) n FROM users'),
  addUser: db.prepare('INSERT INTO users(id,email,hash,salt,admin,created) VALUES(?,?,?,?,?,?)'),
  setPass: db.prepare('UPDATE users SET hash=?, salt=? WHERE email=?'),
  addSess: db.prepare('INSERT INTO sessions(token,user_id,exp) VALUES(?,?,?)'),
  sess: db.prepare('SELECT s.user_id, s.exp FROM sessions s WHERE s.token=?'),
  delSess: db.prepare('DELETE FROM sessions WHERE token=?'),
  delUserSess: db.prepare('DELETE FROM sessions WHERE user_id=?'),
  purge: db.prepare('DELETE FROM sessions WHERE exp<?'),
  get: db.prepare('SELECT val,t FROM kv WHERE path=?'),
  set: db.prepare('INSERT INTO kv(path,val,t) VALUES(?,?,?) ON CONFLICT(path) DO UPDATE SET val=excluded.val,t=excluded.t'),
  list: db.prepare("SELECT path,val,t FROM kv WHERE path>=? AND path<? ORDER BY path"),
};

/* ---------- parola ---------- */
const scrypt = (pw, salt) => new Promise((ok, no) => crypto.scrypt(pw, salt, 64, { N: 16384, r: 8, p: 1 }, (e, k) => e ? no(e) : ok(k.toString('hex'))));
async function sifrele(pw) { const salt = crypto.randomBytes(16).toString('hex'); return { salt, hash: await scrypt(pw, salt) }; }
async function sifreDogru(pw, u) {
  const a = Buffer.from(await scrypt(pw, u.salt), 'hex'), b = Buffer.from(u.hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

/* ---------- yönetim komutları ---------- */
if (process.argv[2] === '--sifre') {
  const [em, yeni] = [(process.argv[3] || '').toLowerCase(), process.argv[4] || ''];
  if (!em || yeni.length < 8) { console.error('Kullanım: node server.js --sifre eposta@ornek.com yeniSifre (en az 8 karakter)'); process.exit(1); }
  const u = q.userByEmail.get(em);
  if (!u) { console.error('Böyle bir kullanıcı yok.'); process.exit(1); }
  sifrele(yeni).then(({ salt, hash }) => { q.setPass.run(hash, salt, em); q.delUserSess.run(u.id); console.log('Şifre güncellendi, açık oturumlar kapatıldı.'); });
  return;
}

/* ---------- yardımcılar ---------- */
const cerez = (req) => Object.fromEntries((req.headers.cookie || '').split(';').map(s => s.trim().split('=')).filter(a => a[0]).map(a => [a[0], decodeURIComponent(a.slice(1).join('='))]));
function oturum(req) {
  const tok = cerez(req).bc_oturum; if (!tok) return null;
  const s = q.sess.get(tok); if (!s || s.exp < Date.now()) return null;
  const u = q.userById.get(s.user_id); return u ? { token: tok, id: u.id, email: u.email, admin: !!u.admin } : null;
}
function cerezYaz(res, tok, gun) {
  res.setHeader('Set-Cookie', `bc_oturum=${tok}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${gun * 86400}${COOKIE_SECURE ? '; Secure' : ''}`);
}
function json(res, kod, obj) { const b = JSON.stringify(obj); res.writeHead(kod, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(b); }
function govde(req) {
  return new Promise((ok, no) => {
    let n = 0; const p = [];
    req.on('data', c => { n += c.length; if (n > MAX_GOVDE) { no({ kod: 413, msg: 'Veri çok büyük.' }); req.destroy(); } else p.push(c); });
    req.on('end', () => { try { ok(JSON.parse(Buffer.concat(p).toString('utf8') || 'null')); } catch { no({ kod: 400, msg: 'Geçersiz JSON.' }); } });
    req.on('error', () => no({ kod: 400, msg: 'İstek okunamadı.' }));
  });
}
/* kaba hız sınırı: IP başına dakikada en fazla 10 giriş/kayıt denemesi */
const deneme = new Map();
function sinir(ip) {
  const n = Date.now(), a = (deneme.get(ip) || []).filter(t => n - t < 60000); a.push(n); deneme.set(ip, a);
  if (deneme.size > 5000) for (const [k, v] of deneme) if (!v.some(t => n - t < 60000)) deneme.delete(k);
  return a.length <= 10;
}
const ipOf = req => (process.env.TRUST_PROXY === '1' && (req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || '';

/* ---------- erişim kuralları (Artifact sürümündeki kurallarla aynı) ---------- */
// yol: data/users/<id>/<anahtar> | talep/<id> | onay/<id> | ayar/<ad>
function belgeYetki(me, p, yaz) {
  const s = p.split('/');
  if (s.length === 4 && s[0] === 'data' && s[1] === 'users') return s[2] === me.id;           // yalnızca kendi verisi
  if (s.length === 2 && s[0] === 'talep') return me.admin || s[1] === me.id;                    // müşteri kendi talebi, yönetici hepsi
  if (s.length === 2 && s[0] === 'onay') return yaz ? me.admin : (me.admin || s[1] === me.id);  // onayı yalnızca yönetici yazar
  if (s.length === 2 && s[0] === 'ayar') return yaz ? me.admin : true;                          // IBAN bilgisi: herkes okur, yönetici yazar
  return false;
}
function koleksiyonYetki(me, c) {
  if (c === 'talep' || c === 'onay') return me.admin;
  const s = c.split('/'); if (s.length === 3 && s[0] === 'data' && s[1] === 'users') return s[2] === me.id;
  return false;
}
const yolGecerli = p => typeof p === 'string' && p.length < 200 && /^[A-Za-z0-9_\-\/.çğıöşüÇĞİÖŞÜ]+$/.test(p) && !p.includes('..') && !p.startsWith('/') && !p.endsWith('/');

/* ---------- API ---------- */
async function api(req, res, url) {
  const ip = ipOf(req);
  if (req.method !== 'GET' && !/^application\/json/.test(req.headers['content-type'] || '')) return json(res, 415, { hata: 'İçerik türü application/json olmalı.' });
  if (req.method !== 'GET' && req.headers.origin) { // CSRF: yalnızca aynı kaynaktan
    let o; try { o = new URL(req.headers.origin).host; } catch { o = ''; }
    if (o !== req.headers.host) return json(res, 403, { hata: 'Geçersiz kaynak.' });
  }
  const r = url.pathname;

  if (r === '/api/kayit' && req.method === 'POST') {
    if (!sinir(ip)) return json(res, 429, { hata: 'Çok fazla deneme. Bir dakika sonra tekrar deneyin.' });
    const b = await govde(req); const em = String(b?.em || '').trim().toLowerCase(), pw = String(b?.sifre || '');
    if (!/^\S+@\S+\.\S+$/.test(em) || em.length > 120) return json(res, 400, { hata: 'Geçerli bir e-posta adresi girin.' });
    if (pw.length < 8 || pw.length > 200) return json(res, 400, { hata: 'Şifre en az 8 karakter olmalı.' });
    if (q.userByEmail.get(em)) return json(res, 409, { hata: 'Bu e-posta adresiyle zaten bir hesap var. Giriş yapın.' });
    const admin = ADMIN_EMAIL ? em === ADMIN_EMAIL : q.userCount.get().n === 0;
    const { salt, hash } = await sifrele(pw), id = crypto.randomUUID();
    try { q.addUser.run(id, em, hash, salt, admin ? 1 : 0, Date.now()); } catch { return json(res, 409, { hata: 'Bu e-posta adresiyle zaten bir hesap var. Giriş yapın.' }); }
    const tok = crypto.randomBytes(32).toString('hex'); q.addSess.run(tok, id, Date.now() + OTURUM_GUN * 864e5); cerezYaz(res, tok, OTURUM_GUN);
    return json(res, 200, { id, admin });
  }
  if (r === '/api/giris' && req.method === 'POST') {
    if (!sinir(ip)) return json(res, 429, { hata: 'Çok fazla deneme. Bir dakika sonra tekrar deneyin.' });
    const b = await govde(req); const em = String(b?.em || '').trim().toLowerCase(), pw = String(b?.sifre || '');
    const u = q.userByEmail.get(em);
    const ok = u ? await sifreDogru(pw, u) : (await scrypt(pw, 'x'.repeat(32)), false); // zamanlama farkını azaltır
    if (!ok) return json(res, 401, { hata: 'E-posta veya şifre hatalı.' });
    const tok = crypto.randomBytes(32).toString('hex'); q.addSess.run(tok, u.id, Date.now() + OTURUM_GUN * 864e5); cerezYaz(res, tok, OTURUM_GUN);
    return json(res, 200, { id: u.id, admin: !!u.admin });
  }
  if (r === '/api/cikis' && req.method === 'POST') {
    const m = oturum(req); if (m) q.delSess.run(m.token); cerezYaz(res, '', 0); return json(res, 200, { ok: true });
  }
  const me = oturum(req);
  if (r === '/api/me') return me ? json(res, 200, { id: me.id, admin: me.admin, email: me.email }) : json(res, 401, { hata: 'Oturum yok.' });
  if (!me) return json(res, 401, { hata: 'Oturum yok.' });

  if (r === '/api/doc') {
    const p = url.searchParams.get('path');
    if (!yolGecerli(p) || p.split('/').length % 2) return json(res, 400, { hata: 'Geçersiz yol.' });
    if (req.method === 'GET') {
      if (!belgeYetki(me, p, false)) return json(res, 403, { hata: 'Yetkiniz yok.' });
      const row = q.get.get(p); return json(res, 200, row ? { exists: true, data: JSON.parse(row.val), t: row.t } : { exists: false });
    }
    if (req.method === 'PUT') {
      if (!belgeYetki(me, p, true)) return json(res, 403, { hata: 'Yetkiniz yok.' });
      const b = await govde(req); if (b === null || typeof b !== 'object' || Array.isArray(b)) return json(res, 400, { hata: 'Belge nesne olmalı.' });
      q.set.run(p, JSON.stringify(b), Date.now()); return json(res, 200, { ok: true });
    }
  }
  if (r === '/api/col' && req.method === 'GET') {
    const c = url.searchParams.get('path');
    if (!yolGecerli(c)) return json(res, 400, { hata: 'Geçersiz yol.' });
    if (!koleksiyonYetki(me, c)) return json(res, 403, { hata: 'Yetkiniz yok.' });
    const rows = q.list.all(c + '/', c + '0'), derin = c.split('/').length + 1; // '0' = '/' sonrası ilk karakter
    return json(res, 200, { docs: rows.filter(x => x.path.split('/').length === derin).map(x => ({ id: x.path.split('/').pop(), data: JSON.parse(x.val), t: x.t })) });
  }
  return json(res, 404, { hata: 'Bulunamadı.' });
}

/* ---------- statik dosyalar ---------- */
const TUR = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.woff2': 'font/woff2' };
function statik(req, res, url) {
  let p = decodeURIComponent(url.pathname); if (p === '/') p = '/index.html';
  const f = path.normalize(path.join(PUBLIC, p));
  if (!f.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end('Yasak'); }
  fs.stat(f, (e, st) => {
    if (e || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Sayfa bulunamadı'); }
    const ext = path.extname(f);
    res.writeHead(200, { 'Content-Type': TUR[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=86400' });
    fs.createReadStream(f).pipe(res);
  });
}

const sunucu = http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('X-Frame-Options', 'SAMEORIGIN'); res.setHeader('Referrer-Policy', 'same-origin');
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    statik(req, res, url);
  } catch (e) {
    if (e && e.kod) return json(res, e.kod, { hata: e.msg });
    console.error(e); if (!res.headersSent) json(res, 500, { hata: 'Sunucu hatası.' });
  }
});
setInterval(() => q.purge.run(Date.now()), 3600e3).unref();
sunucu.listen(PORT, HOST, () => console.log(`bizimcari.net hazır: http://${HOST}:${PORT}  (veri: ${DATA_DIR})`));
